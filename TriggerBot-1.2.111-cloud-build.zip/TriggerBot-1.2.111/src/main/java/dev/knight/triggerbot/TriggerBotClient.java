package dev.knight.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public final class TriggerBotClient implements ClientModInitializer {
    private static final float REQUIRED_COOLDOWN = 1.0F;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(TriggerBotClient::onEndClientTick);
    }

    private static void onEndClientTick(MinecraftClient client) {
        if (client == null
                || client.player == null
                || client.world == null
                || client.interactionManager == null) {
            return;
        }

        // Safety boundary: this training helper operates only in single-player.
        if (!client.isInSingleplayer()) {
            return;
        }

        if (client.currentScreen != null || client.player.isSpectator()) {
            return;
        }

        HitResult hit = client.crosshairTarget;
        if (!(hit instanceof EntityHitResult entityHit)) {
            return;
        }

        Entity target = entityHit.getEntity();
        if (!(target instanceof HostileEntity)
                || !target.isAlive()
                || target.isRemoved()) {
            return;
        }

        if (client.player.getAttackCooldownProgress(0.5F) < REQUIRED_COOLDOWN) {
            return;
        }

        client.interactionManager.attackEntity(client.player, target);
        client.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
    }
}
