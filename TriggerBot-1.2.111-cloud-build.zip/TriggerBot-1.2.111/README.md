# TriggerBot 1.2.111 — Fabric client project

Target: Minecraft Java 1.21.11, Fabric Loader 0.19.5, Fabric API 0.141.6+1.21.11, Java 21.

## Behavior
- Single-player only.
- Attacks a hostile mob directly under the crosshair.
- Respects the normal Minecraft attack cooldown.
- Does not attack players and does nothing in multiplayer.
- No Target ESP or anti-cheat bypass is included.

## Build locally
Install a Java 21 JDK and Gradle 8.14.3, then run:

```sh
gradle build --no-daemon
```

The output JAR should appear in `build/libs/`.

## Build in GitHub Actions
1. Create a repository on GitHub and upload the contents of this folder.
2. Open the repository's **Actions** tab and run **Build TriggerBot** (or push to `main`/`master`).
3. When the workflow succeeds, open its run and download the artifact named `TriggerBot-1.2.111-Minecraft-1.21.11`.
4. Extract the artifact ZIP and copy the `.jar` into your FCL Minecraft `mods` folder.

This source has not yet been compiled in this environment. The workflow will expose dependency or mapping errors in its build log if any occur.
